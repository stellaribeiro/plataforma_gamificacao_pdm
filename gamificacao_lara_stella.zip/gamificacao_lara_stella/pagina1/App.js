import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TouchableOpacity, ScrollView, TextInput, Alert } from 'react-native';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('login');

  // Funções de renderização de cada tela
  const renderLoginScreen = () => (
    <View style={styles.screenContainer}>
      <Text style={{ fontSize: 60, marginBottom: 20 }}>🚀</Text>
      <Text style={styles.title}>TechTraining</Text>
      <Text style={styles.subtitle}>Sua jornada de conhecimento começa aqui.</Text>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>E-mail Corporativo</Text>
        <TextInput style={styles.input} placeholder="lara@gmail.com" keyboardType="email-address" autoCapitalize="none" />
      </View>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Senha</Text>
        <TextInput style={styles.input} placeholder="••••••••" secureTextEntry />
      </View>
      <TouchableOpacity style={styles.button} onPress={() => setCurrentScreen('dashboard')}>
        <Text style={styles.buttonText}>Entrar</Text>
      </TouchableOpacity>
    </View>
  );

  const renderDashboardScreen = () => (
    <ScrollView style={styles.scrollContainer}>
      <Text style={styles.titleLeft}>Olá, Lara! 👋</Text>
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statValue}>1.250</Text>
          <Text style={styles.statLabel}>Pontos</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statValue}>Nível 4</Text>
          <Text style={styles.statLabel}>Ranking</Text>
        </View>
      </View>
      <Text style={styles.sectionTitle}>Meus Treinamentos</Text>
      <TouchableOpacity style={styles.card} onPress={() => setCurrentScreen('module')}>
        <View style={{ flex: 1 }}>
          <Text style={styles.cardTitle}>Segurança da Informação</Text>
          <View style={styles.progressBar}><View style={[styles.progressFill, { width: '70%' }]} /></View>
          <Text style={styles.cardSub}>70% concluído</Text>
        </View>
        <Text style={styles.arrow}>➔</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.card}>
        <View style={{ flex: 1 }}>
          <Text style={styles.cardTitle}>Valores & Ética</Text>
          <View style={styles.progressBar}><View style={[styles.progressFill, { width: '20%' }]} /></View>
          <Text style={styles.cardSub}>20% concluído</Text>
        </View>
        <Text style={styles.arrow}>➔</Text>
      </TouchableOpacity>
    </ScrollView>
  );

  const renderModuleScreen = () => (
    <View style={styles.screenContainer}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setCurrentScreen('dashboard')}>
          <Text style={styles.backBtn}>← Voltar</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Segurança</Text>
      </View>
      
      {/* Parte do vídeo removida, focando agora no conteúdo textual */}
      <View style={styles.contentBox}>
        <Text style={styles.sectionTitle}>Conteúdo do Módulo</Text>
        <Text style={styles.paragraph}>
          A segurança da informação é responsabilidade de todos. Neste treinamento, aprendemos que:
          {"\n\n"}
          1. Senhas devem ser fortes e nunca compartilhadas.{"\n"}
          2. E-mails de remetentes desconhecidos podem conter Phishing.{"\n"}
          3. Dispositivos devem ser bloqueados ao sair da mesa.
        </Text>
      </View>

      <TouchableOpacity style={[styles.button, { backgroundColor: '#10b981' }]} onPress={() => setCurrentScreen('quiz')}>
        <Text style={styles.buttonText}>Iniciar Desafio (+50 XP)</Text>
      </TouchableOpacity>
    </View>
  );

  const renderQuizScreen = () => (
    <View style={styles.screenContainer}>
      <Text style={styles.sectionTitle}>Desafio Rápido ⚡</Text>
      <Text style={styles.question}>Um colega pede sua senha por mensagem. O que você faz?</Text>
      <TouchableOpacity style={styles.quizOption} onPress={() => Alert.alert('Ops!', 'Errado! Nunca compartilhe sua senha.')}>
        <Text>Forneço a senha para ajudar.</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.quizOption} onPress={() => setCurrentScreen('ranking')}>
        <Text>Recuso e reporto ao TI.</Text>
      </TouchableOpacity>
      <Text style={styles.footerText}>Questão 1 de 5</Text>
    </View>
  );

  const renderRankingScreen = () => (
    <ScrollView style={styles.scrollContainer}>
      <Text style={styles.title}>Suas Conquistas 🏆</Text>
      <View style={styles.badgeRow}>
        <Text style={styles.badge}>🥇</Text>
        <Text style={styles.badge}>🛡️</Text>
        <Text style={styles.badge}>👀</Text>
      </View>
      <Text style={styles.sectionTitle}>Ranking da Empresa</Text>
      <View style={[styles.card, { backgroundColor: '#fffbeb' }]}>
        <Text style={{ flex: 1 }}>1. Ana Silva</Text>
        <Text style={{ fontWeight: 'bold' }}>2.450 pts</Text>
      </View>
      <View style={[styles.card, { backgroundColor: '#eff6ff' }]}>
        <Text style={{ flex: 1 }}>3. Você (Lara)</Text>
        <Text style={{ fontWeight: 'bold' }}>1.300 pts</Text>
      </View>
      <TouchableOpacity style={styles.button} onPress={() => setCurrentScreen('dashboard')}>
        <Text style={styles.buttonText}>Voltar ao Início</Text>
      </TouchableOpacity>
    </ScrollView>
  );

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {currentScreen === 'login' && renderLoginScreen()}
        {currentScreen === 'dashboard' && renderDashboardScreen()}
        {currentScreen === 'module' && renderModuleScreen()}
        {currentScreen === 'quiz' && renderQuizScreen()}
        {currentScreen === 'ranking' && renderRankingScreen()}
      </View>

      {currentScreen !== 'login' && (
        <View style={styles.navBottom}>
          <TouchableOpacity style={styles.navItem} onPress={() => setCurrentScreen('dashboard')}>
            <Text style={currentScreen === 'dashboard' ? styles.navActive : styles.navInactive}>🏠 Início</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navItem} onPress={() => setCurrentScreen('ranking')}>
            <Text style={currentScreen === 'ranking' ? styles.navActive : styles.navInactive}>🏆 Ranking</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navItem} onPress={() => setCurrentScreen('login')}>
            <Text style={styles.navInactive}>👤 Sair</Text>
          </TouchableOpacity>
        </View>
      )}
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  content: { flex: 1, paddingTop: 50 },
  screenContainer: { flex: 1, padding: 20, alignItems: 'center' },
  scrollContainer: { flex: 1, padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#4f46e5', textAlign: 'center', marginBottom: 10 },
  titleLeft: { fontSize: 24, fontWeight: 'bold', color: '#4f46e5', marginBottom: 20 },
  subtitle: { fontSize: 16, color: '#6b7280', textAlign: 'center', marginBottom: 30 },
  inputGroup: { width: '100%', marginBottom: 15 },
  label: { marginBottom: 5, fontWeight: '500' },
  input: { width: '100%', backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db' },
  button: { width: '100%', backgroundColor: '#4f46e5', padding: 15, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  statBox: { flex: 1, backgroundColor: '#fff', padding: 15, borderRadius: 12, alignItems: 'center', marginHorizontal: 5, elevation: 2 },
  statValue: { fontSize: 18, fontWeight: 'bold', color: '#4f46e5' },
  statLabel: { fontSize: 12, color: '#6b7280' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginVertical: 15, alignSelf: 'flex-start' },
  card: { flexDirection: 'row', backgroundColor: '#fff', padding: 15, borderRadius: 12, marginBottom: 10, alignItems: 'center', borderWidth: 1, borderColor: '#e5e7eb' },
  cardTitle: { fontWeight: 'bold' },
  cardSub: { fontSize: 12, color: '#6b7280' },
  progressBar: { height: 8, backgroundColor: '#e5e7eb', borderRadius: 4, marginVertical: 8, width: '100%' },
  progressFill: { height: '100%', backgroundColor: '#10b981', borderRadius: 4 },
  arrow: { fontSize: 18, color: '#6b7280', marginLeft: 10 },
  header: { flexDirection: 'row', alignItems: 'center', width: '100%', marginBottom: 20 },
  backBtn: { color: '#4f46e5', fontWeight: 'bold' },
  headerTitle: { flex: 1, textAlign: 'center', fontSize: 20, fontWeight: 'bold', marginRight: 50 },
  contentBox: { width: '100%', marginVertical: 20, backgroundColor: '#fff', padding: 15, borderRadius: 12 },
  paragraph: { lineHeight: 22, color: '#374151' },
  question: { fontSize: 16, marginBottom: 20, textAlign: 'center' },
  quizOption: { width: '100%', backgroundColor: '#fff', padding: 15, borderRadius: 8, marginBottom: 10, borderWidth: 1, borderColor: '#d1d5db' },
  footerText: { marginTop: 20, color: '#6b7280' },
  badgeRow: { flexDirection: 'row', justifyContent: 'center', marginBottom: 20 },
  badge: { fontSize: 40, marginHorizontal: 10 },
  navBottom: { flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e5e7eb', paddingVertical: 10, paddingBottom: 25 },
  navItem: { flex: 1, alignItems: 'center' },
  navActive: { color: '#4f46e5', fontWeight: 'bold' },
  navInactive: { color: '#6b7280' },
});
